Setup:

run npm install to install the dependencies
